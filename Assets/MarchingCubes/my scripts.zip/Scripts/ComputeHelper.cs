using UnityEngine;
using UnityEngine.Experimental.Rendering;
using ComputeShaderUtility;



public static class ComputeHelper
{
    // This class will help in the creation and use of Compute Shaders.
    // Will be implemented soon.
}
